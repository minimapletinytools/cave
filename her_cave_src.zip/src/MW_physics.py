def collideRectCircle(rct,crc):
    pass