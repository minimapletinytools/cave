Her Cave



A boy and a girl exploring a cave

to play: launch src/main.py
If there any any issues, try windowed version, change "isFull" to 0 in MW_constant.py



Controls:
	
ESC - quit
	
TAB - change characters

As the boy:
	
LEFT RIGHT - move
	
UP - jump

As the girl:
	
LEFT RIGHT - move
	
UP - jump
	
DOWN - crouch/crawl

Z - use lighter, lights torches when near




If full screen version runs slow or crashes, try windowed version.

Credits:

Peter Lu



And thanks to:

Anton Bobkov, my friends at selectbutton and my friends at DESMAHAUS, and everyone else who helped test the game for me.
