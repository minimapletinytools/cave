import pygame
import PEG_mainLoop
import PEG_entity
from PEG_datatypes import *

#factory mojo
def quickEffect(id, pos = Vector2d(0,0),color = (255,255,255), radius = 300):
    if id == 1:
        return EffectNova(PEG_mainLoop.mainLoop().entityDict['EffectMenu'], pos,2000,radius,color,pointFunctionSquigglyPoly)

class EffectMenu(PEG_entity.Entity):
    def __init__(self,exml=None):
        PEG_entity.Entity.__init__(self,Rect2d(0,0,0,0))
        self.effectList = list()
        self.deleteList = []
        self.screen = PEG_mainLoop.mainLoop().screen
        #self.effectList.append(EffectNova(self,Vector2d(100,100),4000,500,(255,255,255),pointFunctionSquigglyPoly))
        
    def update(self):
        for e in self.effectList:
            e.updateTime()
            
        self.deleteRoutine()
        
    def addEffect(self,effect):
        self.effectList.append(effect)
            
    def draw(self):
        for e in self.effectList:
            e.draw()
            
    def deleteEntity(self, e):
        self.deleteList.append(e)
    
    def deleteRoutine(self):
        for e in self.deleteList:
            self.effectList.remove(e)
        self.deleteList = []
    
class Effect:
    def __init__(self,parent, position = Vector2d(0,0), expiration = 0):
        self.startTime = pygame.time.get_ticks()
        self.lastUpdate = pygame.time.get_ticks()
        self.p = parent
        self.exp = expiration
        self.pos = position
    def updateTime(self):
        self.lastUpdate = pygame.time.get_ticks()
        if self.lastUpdate > self.startTime + self.exp:
            self.deleteSelf()
    def deleteSelf(self):
        self.p.deleteEntity(self)
    def draw(self):
        pass
    
class EffectNova(Effect):
    def __init__(self,parent,position,expiration,maxRadius,color,pointFunction):
        Effect.__init__(self,parent,position,expiration)
        self.maxRadius = maxRadius
        self.color = color
        self.pointFunction = pointFunction
    def draw(self):
        radius = self.maxRadius*(self.lastUpdate - self.startTime)/self.exp
        pygame.draw.polygon(
                            self.p.screen,
                            self.color,
                            self.pointFunction(self.pos,radius),
                            1
                            )

import PEG_draw
def pointFunctionSquigglyPoly(pos,radius):
    return convertToTupleList(map(pos.__add__,PEG_draw.getGaussianGon(radius, radius + 10, 0.1, 0.3)))