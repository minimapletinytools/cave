import pygame
from PEG_datatypes import *
import PEG_mainLoop
import PEG_camera
import xml.dom.minidom
import PEG_helpers
from PEG_constants import *


class Entity:
    def __init__(self, position = Rect2d(0,0,0,0)):
        """initialize Entity at position position
        
        position: Vector2d"""
        self.pos = position
        self.vel = Vector2d(0,0)
        
    def teleport(self, position):
        """moves entity to position
        
        position: PEG_datatypes.Vector2d"""
        self.pos.x = position.x
        self.pos.y = position.y
        
    def draw(self):
        pass
    
    def update(self):
        pass
    
    def getxml(self):
        return None
    
import pedo_lookup
    
class MovingEntity(Entity):
    def __init__(self, position = Rect2d(0,0,0,0)):
        Entity.__init__(self,position)
    def collide(self,e):
        """is called when there is a colision with Entity e
        
        e: Entity that is collided with"""
        pass
        
class StaticEntity(Entity):
    def __init__(self, position = Rect2d(0,0,0,0)):
        Entity.__init__(self,position)

class SolidEntity(StaticEntity):
    def __init__(self, exml):
        """loads a static terrain square
        
        img: string filename of image"""
        tr = Rect2d(0,0,0,0)
        if exml.hasAttribute("x"):
            tr.x = float(exml.getAttribute("x"))
        if exml.hasAttribute("y"):
            tr.y = float(exml.getAttribute("y"))
        if exml.hasAttribute("w"):
            tr.w = float(exml.getAttribute("w"))
        if exml.hasAttribute("h"):
            tr.h = float(exml.getAttribute("h"))
        if exml.hasAttribute("img"):
            self.mainSurface = pygame.image.load(exml.getAttribute("img")).convert()
            self.mainSurface.set_colorkey(COLOR_GREEN,pygame.RLEACCEL)
        
        self.myxml = exml
        StaticEntity.__init__(self,tr)
        
    def draw(self):
        PEG_mainLoop.mainLoop().cam.drawOnScreen(self.mainSurface, self.pos)
    
    def getxml(self):
        self.myxml.setAttribute("x", str(self.pos.x))
        self.myxml.setAttribute("y", str(self.pos.y)) 
        return self.myxml
    
    
import PEG_visext
import pedo_lookup
class SelectMenu(Entity):
    def __init__(self,exml=None):
        """a select menu to choose things...
        
        exml: xml.dom.element"""
        
        #extract number of menu items
        #calculate # of rows and sizes
        #create button surfaces and button down surfaces
        #draw button surfaces onto main surface
        self.destroy = False
        self.buttonList =[
                        PEG_visext.TextButton01(Rect2d(125, 90,150,60), (255,0,0), "RED"),
                        PEG_visext.TextButton01(Rect2d(125, 210,150,60), (0,255,255), "CYAN"),
                        PEG_visext.TextButton01(Rect2d(125, 330,150,60), (255,255,0), "YELLOW"),
                       
                        PEG_visext.TextButton01(Rect2d(500, 90,150,60), (0,0,255), "BLUE"),
                        PEG_visext.TextButton01(Rect2d(500, 210,150,60), (255,0,255), "PURPLE"),
                        PEG_visext.TextButton01(Rect2d(500, 330,150,60), (255,127,0), "ORANGE")]

        Entity.__init__(self,Rect2d(0,0,0,0))
        
    def update(self):
        mousePos = pygame.mouse.get_pos()
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.MOUSEBUTTONUP:
                for b in self.buttonList:
                    if b.isPointInside(mousePos):
                        try:
                            PEG_mainLoop.mainLoop().entityDict['Network'].color = b.text
                            print "you have chosen to be ", b.text
                            #send message to server
                            #PEG_mainLoop.mainLoop().entityDict['Network'].blablabla
                            self.destroy = True
                        except:
                            print "self identification failed"
    def draw(self):
        for b in self.buttonList:
            b.drawAbs()
        pass

import PEG_draw
import PEG_speech
class MenuEn(Entity):
    def __init__(self, exml = None):
        Entity.__init__(self,Rect2d(640,0,160,480))
        self.scan = False
        self.selectMode = True
        self.select = SelectMenu()
        self.fieldFake = pygame.image.load("eggleston_tiled.png").convert()

    def update(self):
        #grab input
        mousePos = pygame.mouse.get_pos()
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.MOUSEBUTTONUP:
                if PEG_helpers.livesIn(mousePos,Rect2d(self.pos.x+20,80,120,120)):
                    self.scan = not self.scan
                    print "scan mode: ", self.scan            
#===============================================================================
#                if PEG_helpers.livesIn(mousePos,Rect2d(self.pos.x+20,200,120,120)):
#                    print "box2"
#                if PEG_helpers.livesIn(mousePos,Rect2d(self.pos.x+20,340,120,120)):
#                    print "box3"
#===============================================================================
                    
        if self.selectMode:
            self.select.update()
            if self.select.destroy:
                self.selectMode = False
                del self.select
            #look for clicks on color selection boxes
            #send message to server
    
    def draw(self):
        x = self.pos.x
        screen = PEG_mainLoop.mainLoop().screen

#===============================================================================
#        #we don't need this
#        pygame.draw.rect(screen, FL_COLOR_MENU_BACKGROUND, pygame.Rect(x,-1,162,482), 1)
#===============================================================================

        #text
        PEG_speech.Speech().setSize(12, pedo_lookup.fontList[2])
        PEG_speech.Speech().writeCentered(
                                          screen,
                                          Vector2d(x+140,10),
                                          str(PEG_mainLoop.mainLoop().fps),
                                          FL_COLOR_TIMER
                                          )
        
        PEG_speech.Speech().setSize(50, pedo_lookup.fontList[3])
        PEG_speech.Speech().writeCentered(
                                          screen,
                                          Vector2d(x+80,45),
                                          PEG_mainLoop.mainLoop().entityDict['Network'].gameTime,
                                          FL_COLOR_TIMER
                                          )
        #square button thing
        #pygame.draw.rect(screen,(255,255,255),pygame.Rect(x+20,80,120,120),1)  
#===============================================================================
#        pygame.draw.rect(screen,(255,255,255),pygame.Rect(x+20,200,120,120),2)
#        pygame.draw.rect(screen,(255,255,255),pygame.Rect(x+20,340,120,120),2)
#===============================================================================
        
#===============================================================================
#        PEG_speech.Speech().setSize(15)
#        PEG_speech.Speech().writeCentered(
#                                          screen,
#                                          Vector2d(x+80,470),
#                                          "By: Nokia!!!!! IS SO AWESOME"
#                                          )
#===============================================================================
        
        if self.selectMode:
            self.select.draw()
        
        if self.scan:
            trackPos = Vector2d(0,0)
            try:
                trackPos = PEG_mainLoop.mainLoop().entityDict['Network'].enDict[PEG_mainLoop.mainLoop().entityDict['Network'].color].pos.getPosition()
            except: print "no player identified"
            #move the camera
            PEG_mainLoop.mainLoop().cam.moveTo(trackPos)
            #get subsurface and enlarge 4x
            ss = self.fieldFake.subsurface(self.fieldFake.get_rect().clip(pygame.Rect(trackPos.x,trackPos.y,640,480)))
            #ssfourx = pygame.transform.scale2x(pygame.transform.scale2x(ss))
            ssfourx = ss
            PEG_mainLoop.mainLoop().screen.blit(ssfourx, (0,0))
            
#===============================================================================
#            for e in PEG_mainLoop.mainLoop().entityDict['Network'].enDict:
#                if instanceof(e,StaticEntity):
#                    #convert coordinates and draw on screen
#                    pass
#                
#===============================================================================
            
            #reset the camera
            PEG_mainLoop.mainLoop().cam.moveTo(Vector2d(0,0))
        
class ShapeEn(Entity):
    def __init__(self, exml = None):
        tr = Rect2d(0,0,0,0)
        self.name = ''
        if exml and exml.hasAttribute("x"):
            tr.x = int(exml.getAttribute("x"))
        if exml and exml.hasAttribute("y"):
            tr.x = int(exml.getAttribute("y"))
        if exml and exml.hasAttribute("name"):
            self.name = exml.getAttribute("name")
        Entity.__init__(self,tr)
        self.sides = 5
        self.dsides = 5
        try: self.color = pedo_lookup.colorMap[self.name]
        except: self.color = (255,255,255)
        self.visible = True
        
        self.data = dict()
        self.data['sides'] = self.sides
        self.data['x'] = self.pos.y
        self.data['y'] = self.pos.y

        
        #populate this with current position
        #TODO this only needs to be done on the SERVER
        self.lastPos = []
        for i in range(LAST_POS_QUEUE_LEN):
            self.lastPos.append(self.pos.getPosition())
            
        self.playerAngleDict = dict()
        
    def update(self):
        pass
        
    def updatePos(self):
        self.pos = Rect2d(self.data['x'],self.data['y'],0,0)
        self.sides = self.data['sides']
        self.lastPos.pop(0)
        self.lastPos.append(self.pos.getPosition())
    
    def drawSelfLines(self):
        pygame.draw.lines(
                          PEG_mainLoop.mainLoop().screen,
                          self.color,
                          False,
                          convertToTupleList(map(PEG_mainLoop.mainLoop().cam.convertCrds,self.lastPos))                   
                         )
        
    def drawConnectingLines(self,target):
        """draws lines representing angle gain between self and target
        
        target: ShapeEn"""
        skip = 5
        for i in range(PLAYER_ANGLE_QUEUE_LEN/skip - skip):
            at = i*skip
            pygame.draw.lines(
                          PEG_mainLoop.mainLoop().screen,
                          self.color,
                          False,
                          (self.lastPos[at].getIntTuple(), 
                           target.lastPos[at].getIntTuple(),
                           target.lastPos[at+skip].getIntTuple(),
                           self.lastPos[at+skip].getIntTuple())                   
                         )
            
                
    
    def draw(self):     
        self.drawSelfLines()
        pygame.draw.circle(
                           PEG_mainLoop.mainLoop().screen,
                           FL_COLOR_OUTER_RADIUS_CIRCLE,
                           PEG_mainLoop.mainLoop().cam.convertCrds(self.pos.getPosition()).getIntTuple(),
                           OUTER_RADIUS/2,
                           1
                           )
        
        pygame.draw.circle(
                           PEG_mainLoop.mainLoop().screen,
                           FL_COLOR_INNER_RADIUS_CIRCLE,
                           PEG_mainLoop.mainLoop().cam.convertCrds(self.pos.getPosition()).getIntTuple(),
                           INNER_RADIUS,
                           1
                           )
        
        if self.sides == 999:
            if pygame.time.get_ticks() % 3 == 1:
                self.dsides = random.randint(3,10)
        else:
            self.dsides = self.sides
        pygame.draw.polygon(
                            PEG_mainLoop.mainLoop().screen,
                            self.color,
                            PEG_draw.getNgon(
                                             self.dsides, 
                                             PLAYER_DRAW_RADIUS, 
                                             PEG_mainLoop.mainLoop().cam.convertCrds(self.pos.getPosition())),
                            1
                            )
    
import PEG_server
import PEG_sound
import PEG_effects
import os
class Network(Entity):
    
    def __init__(self, exml = None):
        Entity.__init__(self, Rect2d(0,0,0,0))
        
        self.enDict = dict()
        self.selection = None
        self.gameTime = "00:00"
        self.color = None
        self.send = ''
        
        
        self.server = False
        if exml and exml.hasAttribute("server"):
            if exml.getAttribute("server") == "True":
                self.server = True
        
        if self.server:
            self.mgr = PEG_server.ClntManager()
        else:
            self.mgr = PEG_server.SrvManager()
            
        self.mgr.start()
        
        self.lastTimeWeGrabbedData = 0
        
    def __del__(self):
        try:
            self.mgr.killMe()
            self.mgr.join(1)
        except: print "network closing error -- can ignore this"
        
    def update(self):
               
        #data
        self.grabData()
        if self.server: self.sendData()
        
        #process coordinates
        if self.server:
            self.detectHit()
            self.detectCircling()
            
        #process input
        self.processInput()
            
        #TODO: delete destroyed static resources

    def grabData(self):
          #get data, interpret it, and create objects as needed
        #get all the messages
        recv =''
        try:
            self.mgr.reclock.acquire()
            recv = self.mgr.rec[:]
            self.mgr.rec = []
            self.mgr.reclock.release()
        except: 
            try: self.mgr.reclock.release()
            except: pass
        
        #read in data
        #Messages are in this form:
        #[0:letter representing message type][5:representing object id][21:object name][30:x][39:y][49:state]
        if len(recv) > 0:
            if pygame.time.get_ticks() % 10 == 1:
                print "time since last message grab: ", pygame.time.get_ticks() - self.lastTimeWeGrabbedData 
            self.lastTimeWeGrabbedData = pygame.time.get_ticks()
            for m in recv:
                data = self.defaultParseMessage(m)
                #THIS SHOULD BE FIXED
                try:
                    if data['type'] == "position":
                        self.parseEnData(data)
                    if data['type'] == "time":
                        self.time = data['time'][1:len(data['time'])]   #time data is buffered with a character so we can start it with a 0
                except: print "EFFF: ", m, " ", data
        
    def sendData(self):
        #for each players
        #calculate game time based on ticks
        #send game time
        pass
                                 
    def processInput(self):
        mousePos = pygame.mouse.get_pos()
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.MOUSEBUTTONUP:
                for e in self.enDict.values():
                    if e.visible and e.pos.getPosition().distance(Vector2d(mousePos[0],mousePos[1])) < PLAYER_DRAW_RADIUS:
                        self.selection = e
                        print "you have selected: ", e.name
                                                                                                  
                                                                                                 
                        
        
    def parseEnData(self,d):
        #if player position data
        #print ("<entity type=\""  +d['entity']   +"\" x=\""   +str(d['x'])+"\" y=\""     +str(d['y'])  +"\" />")
        if d['name'] not in self.enDict:
            exml = xml.dom.minidom.parseString("<entity type=\""
                                               +d['entity']
                                               +"\" x=\""
                                               +str(d['x'])
                                               +"\" y=\""
                                               +str(d['y'])
                                               +"\" name=\""
                                               +str(d['name'])
                                               +"\" />").getElementsByTagName("entity")[0]
                                               
            self.enDict[d['name']] = pedo_lookup.enTables(exml)
            print d['entity'], ": ", d['name'], " created!"
            
        if d['type'] == "position":
            try:
                self.enDict[d['name']].data = d
            except: d['name']," data set failed"
            try:
                self.enDict[d['name']].updatePos()
            except: d['name'], "update pos failed"
         
    def makeDefaultMessage(d):
        msg = ''
        for s in d.keys():
            #need to fill s with 0s
            msg += s.zfill(20)
            msg += d[s].zfill(20)
        msg += "00000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        return msg
        
    def defaultParseMessage(self,msg):
        """parses message in format
        [20:client name][40:msg type][60-440: data]
        msg: string
        returns (name,type,data[])
        """
        try:
            data = dict()
            #FORMAT AS DICTIONARY
            #20: DATA NAME
            #40: DATA VALUE
            #if 20: = '' then no data
            for i in range(20):
                #if data is not empty
                if msg[0+i*40:20+i*40].lstrip('0') != "":
                    if msg[20+i*40:40+i*40].lstrip('0') == "":
                        data[msg[0+i*40:20+i*40].lstrip('0')] = 0
                    else:
                        if msg[20+i*40:40+i*40].lstrip('0').isdigit() or msg[20+i*40:40+i*40].lstrip('0').lstrip('-').isdigit():
                            data[msg[0+i*40:20+i*40].lstrip('0')] = int(msg[20+i*40:40+i*40].lstrip('0'))
                        else:
                            data[msg[0+i*40:20+i*40].lstrip('0')] = msg[20+i*40:40+i*40].lstrip('0')
                #no need to continue once we run out of data
                else: break
            #print data
            return data
        except: print "msg parsing failed"
    
    def detectHit(self):
        #inner radiusQ
        for e in self.enDict.itervalues():
            for f in self.enDict.itervalues():
                if e != f:
                    if e.pos.getPosition().distance(f.pos) < INNER_RADIUS:
                        PEG_sound.soundMan().playOnceQuickAndDirty(os.path.join('data','sfx01.wav'))
    
    def detectCircling(self):
        def add(a,b): return a + b
        #outer radius
        for e in self.enDict.itervalues():
            for f in self.enDict.itervalues():
                if e != f:
                    if f.name not in e.playerAngleDict:
                        e.playerAngleDict[f.name] = []
                        for i in range(PLAYER_ANGLE_QUEUE_LEN):
                            e.playerAngleDict[f.name].append(0)
                    if e.pos.getPosition().distance(f.pos) < OUTER_RADIUS:
                        #TODO: write some angle function shit in here
                   
                        angle = getAngle3pt(e.lastPos[len(e.lastPos)-2], f.lastPos[len(f.lastPos)-2], e.lastPos[len(e.lastPos)-1])
                        e.playerAngleDict[f.name].append(angle)
                        e.playerAngleDict[f.name].pop(0)
                    else:
                        #we gain no angles when outside OUTER RADIUS
                        #push and pop zero
                        e.playerAngleDict[f.name].append(0)
                        e.playerAngleDict[f.name].pop(0)
                        pass
                    #TODO: now check if we have lapped the other person
                    try: 
                        #we try as f may not have e set up in his playerAngleDict yet
                        if math.fabs(reduce(add, e.playerAngleDict[f.name])) - math.fabs(reduce(add, f.playerAngleDict[e.name])) > ENCIRCLE_RADIANS:
                            print e.name, " has lapped", f.name
                            PEG_mainLoop.mainLoop().entityDict['EffectMenu'].addEffect(PEG_effects.quickEffect(1, e.pos.getPosition(), (255,255,255), 300))
                            #now create a message
                            msg = dict(e.data)
                            msg["destroy"] = "True"
                            #send it
                    except Exception as inst: pass
                        #print type(inst)     # the exception instance

       
    def draw(self):
        if self.selection != None and self.color != None:
            self.enDict[self.color].drawConnectingLines(self.selection)
        for e in self.enDict.itervalues():
            e.draw()
        
class Editor(Entity):
    def __init__(self, exml = None):
        Entity.__init__(self, Rect2d(0,0,0,0))
        self.cursor = Vector2d(0,0)
        self.topxml = xml.dom.minidom.parse("entities.xml").getElementsByTagName('list')[0]
        self.entityList = self.topxml.getElementsByTagName('entity')
        self.currentItem = 0
        self.activeObject = None
        self.setActive()
        self.mode = "place"
    
    def toggleMode(self):
        if self.mode == "place":
            self.activeObject = None
            self.mode = "edit"
        else:
            if not self.activeObject:
                self.setActive()
            self.mode = "place"
        
    def setActive(self, move = 0):
        if not self.activeObject:
            self.activeObject = pedo_lookup.enTables(self.entityList[self.currentItem])
        else:
            self.currentItem = (self.currentItem + move)%len(self.entityList)
            self.activeObject = pedo_lookup.enTables(self.entityList[self.currentItem])
    
    def setMouse(self):
        self.screenCrds = Vector2d(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
        self.cursor = PEG_mainLoop.mainLoop().cam.convertCrds(self.screenCrds)
        self.cursor.x = PEG_helpers.truncateToMultiple(self.cursor.x, TILING_SIZE.x)
        self.cursor.y = PEG_helpers.truncateToMultiple(self.cursor.y, TILING_SIZE.y)
        if self.activeObject:
            self.activeObject.teleport(self.cursor)
    
    def addMode(self):
        self.setMouse()
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_PAGEUP:
                    self.setActive(1)
                if e.key == pygame.K_PAGEDOWN:
                    self.setActive(-1)
                if e.key == pygame.K_SPACE:
                    self.toggleMode()
            if e.type == pygame.MOUSEBUTTONUP:
                PEG_mainLoop.mainLoop().entityList.append(self.activeObject)
                self.activeObject = pedo_lookup.enTables(self.entityList[self.currentItem].cloneNode(True))
        
    def editMode(self):
        self.setMouse()
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_SPACE:
                    self.toggleMode()
            if e.type == pygame.MOUSEBUTTONUP:
                for e in PEG_mainLoop.mainLoop().entityList:
                    if self.cursor == e.pos.getPosition():
                        self.activeObject = e
                        PEG_mainLoop.mainLoop().deleteEntity(e)
                        self.toggleMode()
        
        
    def update(self):
#===============================================================================
#        for e in PEG_mainLoop.mainLoop().eventList:
#            if e.type == pygame.KEYDOWN:
#                if e.key == pygame.K_LEFT:
#                    PEG_mainLoop.mainLoop().cam.moveToRel(Vector2d(-50,0))
#                if e.key == pygame.K_RIGHT:
#                    PEG_mainLoop.mainLoop().cam.moveToRel(Vector2d(50,0))
#                if e.key == pygame.K_UP:
#                    PEG_mainLoop.mainLoop().cam.moveToRel(Vector2d(0,-50))
#                if e.key == pygame.K_DOWN:
#                    PEG_mainLoop.mainLoop().cam.moveToRel(Vector2d(0,50))
#===============================================================================
        if self.mode == "place":
            self.addMode()
        else:
            self.editMode()
            
        #not very efficienty to be looping through this again but who cares
        for e in PEG_mainLoop.mainLoop().eventList:
            if e.type == pygame.KEYDOWN and e.key == pygame.K_RETURN:
                PEG_mainLoop.mainLoop().saveState(99)
        
    def draw(self):
        if self.activeObject:
            self.activeObject.draw()
        pass