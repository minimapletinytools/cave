True Type Font: DIGITAL-7


EULA
The font Digital-7 is freeware for home using. For commercial use please contuct us.


DESCRIPTION
This font created specially for program Calculator-7 (donwload shareware version: http://www.styleseven.com/ and use 30 days fo free).

The program Calculator-7 offers you the following possibilities:
	* calculate using seven operator: addition, subtraction, multiply, divide, percent, square root, 1 divide to X;
	* set decimal position (0, 2, 3, float) and round type (up, mathematical, down);
	* customize an appearance of work window: scale, fonts for digital panel and buttons, background color;
	* customize an appearance of number in digital panel: leading zero for decimal, thousand separator, decimal separator, digit grouping;
	* calculate total from clipboard (copy data to clipboard from table or text and press one button).


Files in digital-7_font.zip:
        readme.txt     		this file.
        digital-7.ttf    	digital-7 regular font 	version 1.0
	digital-7 (mono).ttf    digital-7 mono font 	version 1.0
	digital-7 (italic).ttf 	digital-7 italic font 	version 1.0

Please visit http://www.styleseven.com/ for download our other programs.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com



AUTHOR
	Sizenko Alexander
	Style-7
	http://www.styleseven.com

	Created: October 7 2008
