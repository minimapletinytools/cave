Cave:
A boy and a girl exploring a cave



please run cave-fullscreen.app



Controls:
	
ESC - quit
	
TAB - change characters

As the boy:
	
LEFT RIGHT - move
	
UP - jump

As the girl:
	
LEFT RIGHT - move
	
UP - jump
	
DOWN - crouch/crawl

Z - use lighter, lights torches when near

If full screen version runs slow, try windowed version.

Credits:

Peter Lu


And thanks to:

Anton Bobkov, my friends at selectbutton and my friends at DESMAHAUS, UCLA games lab for letting me work there, and everyone else who helped test the game for me.

contact: chippermonky@gmail.com